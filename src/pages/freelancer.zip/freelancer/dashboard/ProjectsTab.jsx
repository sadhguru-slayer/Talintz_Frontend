const ProjectsTab = ({ userId, role, isAuthenticated, isEditable }) => {
  // ... rest of the code
}; 