import React from 'react';

const ArchivedChats = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold text-gray-800">Archived Chats</h1>
    </div>
  );
};

export default ArchivedChats; 