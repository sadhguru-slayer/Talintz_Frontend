import React from 'react';

const MessageRequests = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold text-gray-800">Message Requests</h1>
    </div>
  );
};

export default MessageRequests; 