import React from 'react';

const Communities = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold text-gray-800">Communities</h1>
    </div>
  );
};

export default Communities; 