import React from 'react'

const FMessagesLayout = () => {
  return (
    <div>
      
    </div>
  )
}

export default FMessagesLayout
